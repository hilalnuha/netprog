import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NilaiClient {
   public static void main(String args[]){
try {
            String url= "rmi://localhost/object1";
            Object o1=Naming.lookup(url);
            OperasiNilai objNilai=(OperasiNilai) o1;
            System.out.println("ambil Nama: "+objNilai.ambilNama());
            System.out.println("ambil Nilai: "+objNilai.ambilNilai());
            System.out.println("tambah Nilai: "+objNilai.tambahNilai(40));
        } catch (NotBoundException ex) {
            Logger.getLogger(NilaiClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(NilaiClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RemoteException ex) {
            Logger.getLogger(NilaiClient.class.getName()).log(Level.SEVERE, null, ex);
        }      
   }
