import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.rmi.RMISecurityManager;

public class NilaiServer {
    public static void main(String[] args){
	if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
            System.out.println("Security manager installed.");
        } else {
            System.out.println("Security manager already exists.");
        }

        try {
            NilaiImpl objectNilai=new NilaiImpl();
            
                Naming.rebind("object1", objectNilai);
            
        } catch (RemoteException ex) {
            Logger.getLogger(NilaiServer.class.getName()).log(Level.SEVERE, null, ex);
        }catch (MalformedURLException ex) {
                Logger.getLogger(NilaiServer.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}
