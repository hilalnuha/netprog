import HalloApp.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;
import java.util.Properties;
class HalloImpl extends HalloPOA {
private ORB orb;
public void setORB(ORB orb_val) {
orb = orb_val;
}
// implementasi metode ucapkanHallo()
public String ucapkanHallo() {
return "\nHallo Bandung !!\n";
}
// implementasi metode shutdown()
public void shutdown() {
orb.shutdown(false);
}
}
public class HalloServer {
public static void main(String args[]) {
try{
// membuat dan menginisialisasi ORB
ORB orb = ORB.init(args, null);
// referensi ke rootpoa & mengaktifkan POAManager
POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
rootpoa.the_POAManager().activate();
// buat servant dan register-kan ke ORB
HalloImpl HalloImpl = new HalloImpl();
HalloImpl.setORB(orb);
// dapatkan referensi obyek dari servant
org.omg.CORBA.Object ref =
rootpoa.servant_to_reference(HalloImpl);
Hallo href = HalloHelper.narrow(ref);
// dapatkan root naming context
org.omg.CORBA.Object objRef =
orb.resolve_initial_references("NameService");
NamingContextExt ncRef =
NamingContextExtHelper.narrow(objRef);
String name = "Hallo";
NameComponent path[] = ncRef.to_name( name );
ncRef.rebind(path, href);
System.out.println("HalloServer aktif dan menunggu permintaan ...");
// tunggu permintaan dari client
orb.run();
}
catch (Exception e) {
System.err.println("ERROR: " + e);
e.printStackTrace(System.out);
}
System.out.println("HalloServer dimatikan ...");
}
}
