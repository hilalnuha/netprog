import HalloApp.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
public class HalloClient
{
static Hallo HalloImpl;
public static void main(String args[])
{
try{
// membuat dan menginisalisasi ORB
ORB orb = ORB.init(args, null);
// ambil root naming context
org.omg.CORBA.Object objRef =
orb.resolve_initial_references("NameService");
NamingContextExt ncRef =
NamingContextExtHelper.narrow(objRef);
String name = "Hallo";
HalloImpl = HalloHelper.narrow(ncRef.resolve_str(name));
System.out.println("penanganan obyek server : " +
HalloImpl);
System.out.println(HalloImpl.ucapkanHallo());
HalloImpl.shutdown();
} catch (Exception e) {
System.out.println("ERROR : " + e) ;
e.printStackTrace(System.out);
}
}
}
