package beans;

// Fig. 27.14: Rotator.java
  // A JavaBean that rotates advertisements.
   
 
   public class RotatorBean
   {
      private String images[] = { "includePage/apricot.jpg",
         "includePage/apricot.jpg", "includePage/apricot.jpg",
         "includePage/apricot.jpg", "includePage/apricot.jpg" };

     private String links[] = {
        "http://hilalnuha.blogspot.com/",
        "http://inspira-tips.blogspot.com/",
        "http://hilalcenter.multiply.com/",
        "http://hilalnuha.wordpress.com/",
        "http://kuliah-hhn.blogspot.com/"
     };
     
     private String sentences[] = {
        "kunjungi http://hilalnuha.blogspot.com/",
        "kunjungi http://inspira-tips.blogspot.com/",
        "kunjungi http://hilalcenter.multiply.com/",
        "kunjungi http://hilalnuha.wordpress.com/",
        "kunjungi http://kuliah-hhn.blogspot.com/"
     };

     private int selectedIndex = 0;
    public String getSentence()
     {
        return sentences[ selectedIndex ];
     }     

     // returns image file name for current ad
     public String getImage()
     {
        return images[ selectedIndex ];
     } // end method getImage

     // returns the URL for ad's corresponding Web site
     public String getLink()
     {
        return links[ selectedIndex ];
     } // end method getLink

     // update selectedIndex so next calls to getImage and
     // getLink return a different advertisement
     public void nextAd()
     {
        selectedIndex = ( selectedIndex + 1 ) % images.length;
     } // end method nextAd
} // end class Rotator
