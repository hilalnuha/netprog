import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;

/**
 *
 * @author USER
 */
public class TCPEchoServer {
    private static final int BUFSIZE=32;
    public static void main(String args[]) throws IOException{
        int portServ=7;
    if (args.length>1) {
    portServ=Integer.parseInt(args[0]);
    }
    //else {
    //throw new IllegalArgumentException("parameter <port>");
    //}

        ServerSocket servSock=new ServerSocket(portServ);
        int recvMsgSize;
        byte[] recvBuf=new byte[BUFSIZE];
        while (true){
        Socket clntSock=servSock.accept();
        SocketAddress clientAddress=clntSock.getRemoteSocketAddress();
        System.out.println("Menangani Client at:"+clientAddress);
        InputStream in=clntSock.getInputStream();
        OutputStream out=clntSock.getOutputStream();

        while ((recvMsgSize=in.read(recvBuf))!=-1){
            out.write(recvBuf,0,recvMsgSize);

        }
            clntSock.close();
        }

    }

}
