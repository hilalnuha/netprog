import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author USER
 */
public class TCPEchoClient {
    public static void main(String args[]) throws UnknownHostException, IOException{
    if (args.length<2||args.length>3){
        throw new IllegalArgumentException("Parameters: <server> <word> [<port>]");
    }
//
//
}
