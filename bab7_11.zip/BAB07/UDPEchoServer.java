import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPEchoServer {
    private static final int ECHOMAX=255;
    public static void main(String args[]) throws SocketException, IOException{
    int servPort=7;
    DatagramSocket socket=new DatagramSocket(servPort);
    DatagramPacket packet=new DatagramPacket(new byte[ECHOMAX], ECHOMAX);
    while (true){
    socket.receive(packet);
    System.out.println("Menangani paket dari "+packet.getAddress().getHostAddress()+" pada port "+packet.getPort());
    socket.send(packet);
    packet.setLength(ECHOMAX);
    }
    }

}
