import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;


public class UDPEchoClientTimeOut {

    private static final int TIMEOUT = 3000;
    private static final int MAXTRIES = 5;

    public static void main(String args[]) throws UnknownHostException, SocketException, IOException {
        if (args.length < 2 || args.length > 3) {
            throw new IllegalArgumentException("parameter <server> <word> [<port>]");
        }

        InetAddress serverAddress = InetAddress.getByName(args[0]);
        byte[] byteToSend = args[1].getBytes();


        int servPort = (args.length == 3) ? Integer.parseInt(args[2]) : 7;
        DatagramSocket socket = new DatagramSocket();
        socket.setSoTimeout(TIMEOUT);
        DatagramPacket sendPacket = new DatagramPacket(byteToSend, byteToSend.length, serverAddress, servPort);
        DatagramPacket recvPacket = new DatagramPacket(new byte[byteToSend.length], byteToSend.length);
        int tries = 0;
        boolean receivedResponse = false;
        do {
            socket.send(sendPacket);
            try {
                socket.receive(recvPacket);
                if (!recvPacket.getAddress().equals(serverAddress)) {
                    throw new IOException("diterima dari sumber yang tidak dikenal");
                }
                receivedResponse = true;
            } catch (InterruptedIOException e) {
                tries += 1;
                System.out.println("tidak diterima, " + (MAXTRIES - tries) + " kali lagi");

            }

        } while ((!receivedResponse) && (tries < MAXTRIES));

        if (receivedResponse) {
       System.out.println("Diterima: " + new String(recvPacket.getData()));
        } else {
            System.out.println("Tidak ada balasan -- menyerah");
        }
        socket.close();
    }
}
